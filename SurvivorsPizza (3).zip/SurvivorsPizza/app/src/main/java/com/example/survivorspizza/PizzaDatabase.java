package com.example.survivorspizza;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

public class PizzaDatabase extends Application {


private static final String PIZZA_DATABASE = "db_pizza_orders";
    private static final int DB_Version = 1;
    private SQLiteOpenHelper order ;
    @Override
    public void onCreate() {

         order = new  SQLiteOpenHelper(this, PIZZA_DATABASE,null, DB_Version){
            @Override
            public void onCreate(SQLiteDatabase sqLiteDatabase) {
                sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS tbl_orders(" + "firstname REAL, lastName REAL, meat REAL, veg REAL, cheese REAL)");
            }

            @Override
            public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

            }


        };


        super.onCreate();
    }
    public void addOrder(String orderTicket)
    {
        SQLiteDatabase db = order.getWritableDatabase();
        db.execSQL("INSERT INTO tbl_orders(firstName,lastName, meat, veg, cheese)"+ "VALUES(" + orderTicket +")");
    }
}

