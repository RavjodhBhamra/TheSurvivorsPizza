package com.example.survivorspizza;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PizzaDatabase2 extends AppCompatActivity {


}