package com.example.survivorspizza;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button buttonClear;
    private Button submit;
    private RadioButton special;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonClear = findViewById(R.id.button2);
        submit = findViewById(R.id.button3);
        special = findViewById(R.id.radioButton);


        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String clear = buttonClear.getText().toString();


                RadioButton spec2 = (RadioButton) findViewById(R.id.radioButton2);
                RadioButton spec3 = (RadioButton) findViewById(R.id.radioButton3);


                    spec2.setSelected(false);
                    spec3.setSelected(false);


                   special.setSelected(false);



            special.clearFocus();

            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              /*  final PizzaDatabase app = ((PizzaDatabase) getApplication());
                app.addOrder(0);

               */

            }



            public boolean onCreateOptionsMenu(Menu menu) {
                getMenuInflater().inflate(R.menu.menu, menu);
                return true;
            }


            public boolean onOptionsItemSelected(@NonNull MenuItem item) {
                boolean retkun = true;
                switch(item.getItemId()) {

                    case R.id.pizza_datebase:
                        //TODO get Statistics
                        Intent intent = new Intent(getApplicationContext(), PizzaActivity.class);
                        startActivity(new Intent(getApplicationContext(), PizzaActivity.class));
                        // intent.putExtra("sync",darkMode);

                        break;
                    default:
                        retkun = MainActivity.super.onOptionsItemSelected(item);
                        break;
                }


                return retkun;
            }

        });




    }



}